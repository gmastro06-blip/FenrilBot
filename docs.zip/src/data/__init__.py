"""Data catalogs used by Fenril.

Kept small and dependency-free; optionally refreshable via scripts.
"""
