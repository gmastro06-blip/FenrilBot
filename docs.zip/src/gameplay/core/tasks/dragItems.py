import time
from src.repositories.inventory.core import images
from src.shared.typings import GrayImage
from src.utils.core import locate
from src.utils.mouse import drag, rightClick
from src.gameplay.typings import Context
from .common.base import BaseTask


# TODO: check if item was moved on did. Is possible to check it by cap
class DragItemsTask(BaseTask):
    def __init__(self: "DragItemsTask", containerBarImage: GrayImage, targetContainerImage: GrayImage) -> None:
        super().__init__(delayOfTimeout=25.0)
        self.name = 'dragItems'
        self.terminable = False
        self.timeout_config_path = 'ng_runtime.task_timeouts.dragItems'
        self.timeout_env_var = 'FENRIL_DRAG_ITEMS_TIMEOUT'
        self.timeout_default = 25.0
        self.shouldTimeoutTreeWhenTimeout = True
        self.containerBarImage = containerBarImage
        self.targetContainerImage = targetContainerImage

    # TODO: add unit tests
    def do(self, context: Context) -> Context:
        if context.get('ng_screenshot') is None:
            return context
        containerBarPosition = locate(context['ng_screenshot'], self.containerBarImage, confidence=0.8)
        if containerBarPosition is None:
            return context
        firstSlotImage = context['ng_screenshot'][containerBarPosition[1] + 18:containerBarPosition[1] + 18 + 32, containerBarPosition[0] + 10:containerBarPosition[0] + 10 + 32]
        isLootBackpackItem = locate(firstSlotImage, images['slots'][context['ng_backpacks']['loot']], confidence=0.8) is not None
        if isLootBackpackItem:
            rightClick((containerBarPosition[0] + 12, containerBarPosition[1] + 20))
            return context
        isNotEmptySlot = locate(firstSlotImage, images['slots']['empty']) is None
        if isNotEmptySlot:
            targetContainerPosition = locate(context['ng_screenshot'], self.targetContainerImage, confidence=0.8)
            if targetContainerPosition is None:
                return context
            fromX, fromY = containerBarPosition[0] + 12, containerBarPosition[1] + 20
            toX, toY = targetContainerPosition[0] + 2, targetContainerPosition[1] + 2
            drag((fromX, fromY), (toX, toY))
            time.sleep(0.4)
            return context
        self.terminable = True
        return context
