import src.gameplay.utils as gameplayUtils
import src.repositories.gameWindow.core as gameWindowCore
import src.repositories.gameWindow.slot as gameWindowSlot
from src.shared.typings import Waypoint
from ...typings import Context
from .common.base import BaseTask


class ClickInCoordinateTask(BaseTask):
    def __init__(self: "ClickInCoordinateTask", waypoint: Waypoint) -> None:
        super().__init__()
        self.name = 'clickInCoordinate'
        self.delayBeforeStart = 1
        self.delayAfterComplete = 0.5
        self.waypoint = waypoint

    def do(self, context: Context) -> Context:
        slot = gameWindowCore.getSlotFromCoordinate(
            context['ng_radar']['coordinate'], self.waypoint['coordinate'])
        if slot is None:
            return context
        gameWindowSlot.clickSlot(slot, context['gameWindow']['coordinate'])
        return context

    def did(self, context: Context) -> bool:
        return gameplayUtils.coordinatesAreEqual(context['ng_radar']['coordinate'], context['ng_cave']['waypoints']['state']['checkInCoordinate'])
