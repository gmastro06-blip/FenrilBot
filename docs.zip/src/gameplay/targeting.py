import os

from .typings import Context
from src.utils.runtime_settings import get_bool


# TODO: add unit tests
def hasCreaturesToAttack(context: Context) -> bool:
    context['ng_targeting']['hasIgnorableCreatures'] = False

    # Primary signal: on-screen monsters.
    if len(context['gameWindow']['monsters']) == 0:
        # Optional fallback: use battle list presence as a signal that there
        # are attackable creatures even when on-screen monster detection fails.
        # This is intentionally opt-in because the battle list can include
        # players/NPCs depending on client filters.
        bl_creatures = context.get('ng_battleList', {}).get('creatures')
        bl_count = len(bl_creatures) if bl_creatures is not None else 0
        if bl_count > 0 and get_bool(context, 'ng_runtime.attack_from_battlelist', env_var='FENRIL_ATTACK_FROM_BATTLELIST', default=False):
            # Only treat battle list as "attackable" if we can actually pick a target
            # based on names/ignore lists. This prevents infinite attacking when the
            # battle list contains only ignored entries (players/NPCs/Unknown).
            try:
                from src.repositories.battleList.selection import choose_target_index

                idx, _, _ = choose_target_index(context)
            except Exception:
                idx = None
            if idx is None:
                context['ng_targeting']['canIgnoreCreatures'] = True
                return False
            context['ng_targeting']['canIgnoreCreatures'] = True
            return True

        context['ng_targeting']['canIgnoreCreatures'] = True
        return False
    if context['ng_targeting']['canIgnoreCreatures'] == False:
        return True
    ignorableGameWindowCreatures = []
    for gameWindowCreature in context['gameWindow']['monsters']:
        shouldIgnoreCreature = context['ng_targeting']['creatures'].get(gameWindowCreature['name'], { 'ignore': True if gameWindowCreature['name'] in context['ignorable_creatures'] else False })['ignore']
        if shouldIgnoreCreature:
            context['ng_targeting']['hasIgnorableCreatures'] = True
            ignorableGameWindowCreatures.append(gameWindowCreature)
    return len(ignorableGameWindowCreatures) < len(context['gameWindow']['monsters'])
